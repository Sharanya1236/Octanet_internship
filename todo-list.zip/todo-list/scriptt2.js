// script.js
document.getElementById('add-task').addEventListener('click', function() {
    const taskInput = document.getElementById('task-input');
    const categorySelect = document.getElementById('category-select');
    const prioritySelect = document.getElementById('priority-select');
    const dueDateInput = document.getElementById('due-date');

    if (taskInput.value.trim() === '') {
        alert('Please enter a task.');
        return;
    }

    const task = {
        text: taskInput.value,
        category: categorySelect.value,
        priority: prioritySelect.value,
        dueDate: dueDateInput.value,
        completed: false
    };

    addTaskToList(task);
    taskInput.value = '';
    categorySelect.value = 'general';
    prioritySelect.value = 'low';
    dueDateInput.value = '';
});

function addTaskToList(task) {
    const taskList = document.getElementById('task-list');

    const li = document.createElement('li');
    li.classList.add(task.category);
    li.classList.add(task.priority);

    const taskText = document.createElement('span');
    taskText.textContent = `${task.text} (Due: ${task.dueDate})`;
    if (task.completed) {
        taskText.classList.add('completed');
    }

    const completeButton = document.createElement('button');
    completeButton.textContent = 'Complete';
    completeButton.addEventListener('click', function() {
        taskText.classList.toggle('completed');
    });

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', function() {
        taskList.removeChild(li);
    });

    li.appendChild(taskText);
    li.appendChild(completeButton);
    li.appendChild(deleteButton);

    taskList.appendChild(li);
}
